import React, { useState } from 'react';
import { View, Button, StyleSheet, Text, Alert } from 'react-native';
import xml2js from 'react-native-xml2js';  // Import xml2js for XML parsing

const App = () => {
  const [xmlData, setXmlData] = useState(null);

  // Handler for rendering form from XML file
  const renderFormFromFile = () => {
    Alert.alert("Rendering form from XML file...");

    // Logic to load and parse XML file (example using a local XML string)
    const xmlString = `<form><field name="name">John Doe</field><field name="email">john@example.com</field></form>`;
    
    xml2js.parseString(xmlString, (err, result) => {
      if (err) {
        Alert.alert("Error", "Failed to parse XML");
      } else {
        console.log(result);  // Log the parsed XML result
        setXmlData(result);  // Save parsed data to state
        Alert.alert("XML parsed successfully!");
      }
    });
  };

  // Handler for rendering form from XML input
  const renderFormFromInput = () => {
    Alert.alert("Rendering form from XML input...");
    // Logic to accept XML input from the user can go here
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>XML Form Renderer</Text>
      <Button title="Render Form from XML File" onPress={renderFormFromFile} />
      <View style={styles.spacer} />
      <Button title="Render Form from XML Input" onPress={renderFormFromInput} />
      {xmlData && <Text>{JSON.stringify(xmlData)}</Text>}  {/* Display parsed XML data */}
    </View>
  );
};

// Styles for the main screen
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    marginBottom: 40,
    fontWeight: 'bold',
    color: '#333',
  },
  spacer: {
    height: 20,
  },
});

export default App;
